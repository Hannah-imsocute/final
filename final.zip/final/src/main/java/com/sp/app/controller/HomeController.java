package com.sp.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
public class HomeController {
	
	@GetMapping("/")
	public String handleHome(Model model) {
		
		return "main/main";
	}

	@GetMapping("/test")
	public String handleHome2(Model model) {
		
		return "member/register";
	}
	
}
