package com.sp.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/test/*")
public class TestController {

	  @GetMapping("list")
	  public String cartList() {
	    return "test/list";
	  }
	  
	  @GetMapping("list2")
	  public String cartList2() {
	    return "mypage/home";
	  }
	  
	  
	  
}
