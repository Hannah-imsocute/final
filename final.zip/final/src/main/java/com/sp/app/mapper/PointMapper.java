package com.sp.app.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PointMapper {
}
