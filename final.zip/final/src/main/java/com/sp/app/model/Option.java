package com.sp.app.model;

public class Option {
}
